class SchemaRegistryException(Exception):
    pass
